/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

public class StockTransaction {
    private int shares;
    private double pricePerShare;
    private double commissionRate;

    public StockTransaction() {
        this.commissionRate = 0.05;
    }

    public double getAmountPaidForStock() {
        return shares * pricePerShare;
    }

    public double getCommission() {
        return getAmountPaidForStock() * commissionRate;
    }

    public double getTotalAmountPaid() {
        return getAmountPaidForStock() + getCommission();
    }

    // Getters and setters for shares, pricePerShare, and commissionRate
    public int getShares() {
        return shares;
    }

    public void setShares(int shares) {
        this.shares = shares;
    }

    public double getPricePerShare() {
        return pricePerShare;
    }

    public void setPricePerShare(double pricePerShare) {
        this.pricePerShare = pricePerShare;
    }

    public double getCommissionRate() {
        return commissionRate;
    }

    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }
}
