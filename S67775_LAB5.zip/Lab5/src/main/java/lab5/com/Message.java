
package lab5.com;

/**
 *NUR AFIQAH BINTI ROSDI
 * 
 */

public class Message {
    public String msg;
    
    public Message(){
        
}
    
public void setMsg(String msg){
    this.msg = msg;
}

public String getMsg(){
    return msg;
}
}
