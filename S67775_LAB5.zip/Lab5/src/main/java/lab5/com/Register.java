/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab5.com;

public class Register {
    private String trainingName;
    private String IcNo;
    private String trainingType;
    private int paxNo;
    private String student;
    
public Register(){
}
public String getTrainingName() {
    return trainingName;
}

public void setTrainingName(String trainingName) {
    this.trainingName = trainingName;
}

public String getIcNo() {
    return IcNo;
}
   
public void setIcNo(String IcNo) {
    this.IcNo = IcNo;
}

public String getTrainingType() {
    return trainingType;
}

public void setTrainingType(String trainingType) {
    this.trainingType = trainingType;
}

public int getPaxNo() {
    return paxNo;
}

public void setPaxNo(int paxNo) {
    this.paxNo = paxNo;
}

public String getStudent() {
    return student;
}

public void setStudent(String student) {
    this.student = student;
}
}